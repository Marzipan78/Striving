import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image


def app():
    
    # Web App Title
    st.markdown('''
    # **STRAIGHT TO IT**

    Based on the data that we collected and processed, our consensus is that you should indeed look to invest in the **Publishing Industry.**
    
    - Mediums
    - Global Pandemic, People are still at home and need ways to keep themselves busy.
    - Potential Avenues
    - Flexibility and Adaptability.''')

    #image = st.beta_container()
    #with image:
        #st.subheader('Books Published over the Years')
        #image = Image.open('meme.jpeg')
        #st.image(image, caption='Evidence')

    


    


        